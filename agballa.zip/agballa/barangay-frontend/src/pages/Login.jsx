import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [role, setRole] = useState("admin");

  const handleLogin = () => {
    login(role);
    navigate("/dashboard"); // redirect after login
  };

  return (
    <div style={container}>

      <div style={card}>

        <h2>Barangay Login</h2>

        <p>Select Role</p>

        {/* ROLE SELECT */}
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          style={input}
        >
          <option value="admin">Admin</option>
          <option value="resident">Resident</option>
          <option value="guest">Guest</option>
        </select>

        {/* LOGIN BUTTON */}
        <button onClick={handleLogin} style={btn}>
          Login
        </button>

      </div>

    </div>
  );
};

export default Login;

/* ================= STYLES ================= */

const container = {
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "#f3f4f6"
};

const card = {
  background: "white",
  padding: "30px",
  borderRadius: "10px",
  boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
  width: "300px",
  textAlign: "center"
};

const input = {
  width: "100%",
  padding: "10px",
  margin: "10px 0",
  borderRadius: "5px"
};

const btn = {
  width: "100%",
  padding: "10px",
  background: "#2563eb",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer"
};